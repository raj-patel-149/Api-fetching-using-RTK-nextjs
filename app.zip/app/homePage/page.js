import React from "react";
import Categories from "../Components/Categories";

const page = () => {
  return (
    <div className="flex justify-center items-center h-full mt-16">
      <Categories />
    </div>
  );
};

export default page;
