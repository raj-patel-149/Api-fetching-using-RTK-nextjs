import React, { useEffect, useState } from "react";
import axios from "axios";
import CardBox from "./CardBox";
import UpdateDialog from "./UpdateDialog";
import DeleteDialog from "./DeleteDialog";
import AddDialog from "./AddDialog";
import { Button } from "@mui/material";

const CardContainer = ({ category }) => {
  const [products, setProducts] = useState([]);
  const [updateProduct, setUpdateProduct] = useState(null);
  const [updateOpen, setUpdateOpen] = useState(false);
  const [deleteProduct, setDeleteProduct] = useState(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      if (!category) return;
      try {
        const response = await axios.get(
          `https://fakestoreapi.com/products/category/${category}`
        );
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, [category]);

  const handleUpdateClick = (product) => {
    setUpdateProduct(product);
    setUpdateOpen(true);
  };

  const handleUpdateConfirm = async (updatedData) => {
    try {
      let imageUrl = updateProduct.image;

      if (updatedData.image instanceof File) {
        imageUrl = URL.createObjectURL(updatedData.image);
      }

      const updatedProduct = {
        ...updateProduct,
        ...updatedData,
        image: imageUrl,
      };

      const response = await axios.put(
        `https://fakestoreapi.com/products/${updateProduct.id}`,
        updatedProduct
      );

      const newUpdatedProduct = response.data;

      setProducts((prevProducts) =>
        prevProducts.map((p) =>
          p.id === newUpdatedProduct.id ? newUpdatedProduct : p
        )
      );

      setUpdateOpen(false);
      setUpdateProduct(null);
    } catch (error) {
      console.error("Error updating product:", error);
    }
  };

  const handleDeleteClick = (product) => {
    setDeleteProduct(product);
    setDeleteOpen(true);
  };

  const handleDeleteConfirm = async () => {
    try {
      await axios.delete(
        `https://fakestoreapi.com/products/${deleteProduct.id}`
      );

      setProducts((prevProducts) =>
        prevProducts.filter((p) => p.id !== deleteProduct.id)
      );

      setDeleteOpen(false);
      setDeleteProduct(null);
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  const handleAddClick = () => {
    setAddOpen(true);
  };

  const handleConfirmAdd = (newProduct) => {
    const newProductWithID = {
      ...newProduct,
      id: Date.now(),
    };
    setProducts((prevProducts) => [newProductWithID, ...prevProducts]);
    setAddOpen(false);
  };

  return (
    <div className="mt-5">
      <Button
        variant="contained"
        color="primary"
        onClick={handleAddClick}
        style={{ marginBottom: "10px" }}
      >
        Add Product
      </Button>

      <CardBox
        products={products}
        onUpdateClick={handleUpdateClick}
        onDeleteClick={handleDeleteClick}
      />
      <UpdateDialog
        open={updateOpen}
        product={updateProduct}
        onClose={() => setUpdateOpen(false)}
        onConfirm={handleUpdateConfirm}
      />
      <DeleteDialog
        product={deleteProduct}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleDeleteConfirm}
      />

      <AddDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onConfirm={handleConfirmAdd}
      />
    </div>
  );
};

export default CardContainer;
